const makerPage = (req, res) => {
  res.render('app');
};

module.exports.makerPage = makerPage;
